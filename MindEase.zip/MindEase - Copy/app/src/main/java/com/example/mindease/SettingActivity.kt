package com.example.mindease

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class SettingActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_setting)

        // Set up the "Back to Profile" button
        val backToProfileButton: Button = findViewById(R.id.back_to_profile_button)
        backToProfileButton.setOnClickListener {
            // Intent to navigate back to ProfileActivity
            val intent = Intent(this, UserProfileActivity::class.java)
            startActivity(intent)
            finish() // Optional, to prevent the user from going back to the settings page
        }
    }
}
