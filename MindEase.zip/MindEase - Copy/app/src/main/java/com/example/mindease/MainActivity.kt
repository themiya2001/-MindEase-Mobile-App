package com.example.mindease

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView
import android.widget.ImageButton

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Initialize feature cards with correct IDs
        val meditationCard = findViewById<CardView>(R.id.meditationCard)
        val moodCard = findViewById<CardView>(R.id.moodCard)
        val sleepCard = findViewById<CardView>(R.id.sleepCard)
        val breathingCard = findViewById<CardView>(R.id.breathingCard)
        val profileButton = findViewById<ImageButton>(R.id.profileButton)

        // Set click listeners for feature cards
        meditationCard.setOnClickListener {
            navigateTo(MeditationActivity::class.java)
        }

        moodCard.setOnClickListener {
            navigateTo(MoodTrackerActivity::class.java)
        }

        sleepCard.setOnClickListener {
            navigateTo(SleepSoundsActivity::class.java)
        }

        breathingCard.setOnClickListener {
            navigateTo(BreathingActivity::class.java)
        }

        profileButton.setOnClickListener {
            navigateTo(UserProfileActivity::class.java)
        }
    }

    private fun navigateTo(activityClass: Class<*>) {
        val intent = Intent(this, activityClass)
        startActivity(intent)
    }
}
