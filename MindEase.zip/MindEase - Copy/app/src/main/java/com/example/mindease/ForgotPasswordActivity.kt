package com.example.mindease

import android.content.Intent
import android.os.Bundle
import android.os.Looper
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.textfield.TextInputEditText

class ForgotPasswordActivity : AppCompatActivity() {

    private lateinit var emailEditText: TextInputEditText
    private lateinit var resetButton: Button
    private lateinit var backToLoginText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_forgot_password) // Ensure XML file matches

        // Initialize views
        emailEditText = findViewById(R.id.emailEditText)
        resetButton = findViewById(R.id.resetButton)
        backToLoginText = findViewById(R.id.backToLoginText)

        // Set click listeners
        resetButton.setOnClickListener {
            handlePasswordReset()
        }

        backToLoginText.setOnClickListener {
            navigateBackToLogin()
        }
    }

    private fun handlePasswordReset() {
        val email = emailEditText.text.toString().trim()

        // Proceed with password reset (No validation)
        simulatePasswordReset(email)
    }

    private fun simulatePasswordReset(email: String) {
        // Simulate network delay
        android.os.Handler(Looper.getMainLooper()).postDelayed({
            Toast.makeText(
                this,
                "Password reset link sent to $email",
                Toast.LENGTH_LONG
            ).show()

            // Navigate back to login
            navigateBackToLogin()
        }, 1500)
    }

    private fun navigateBackToLogin() {
        val intent = Intent(this, LoginActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        startActivity(intent)
        finish()
    }
}
